<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pricing_rules', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('service_area_id');
            $table->unsignedSmallInteger('service_id');
            $table->decimal('base_fee', 10, 2)->default(0.00);
            $table->decimal('per_km_fee', 10, 2)->default(0.00);
            $table->decimal('night_surcharge', 10, 2)->default(0.00);
            $table->dateTime('effective_from');
            $table->dateTime('effective_to')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->foreign('service_area_id', 'fk_pricing_rules_area')
                ->references('id')->on('service_areas')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('service_id', 'fk_pricing_rules_service')
                ->references('id')->on('services')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->unique(['service_area_id', 'service_id', 'effective_from'], 'uq_pricing_rules_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pricing_rules');
    }
};
