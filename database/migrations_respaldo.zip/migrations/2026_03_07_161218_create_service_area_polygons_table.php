<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('service_area_polygons', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('service_area_id');
            $table->geometry('polygon', 'polygon', 4326); // Polígono geoespacial con SRID 4326
            $table->timestamps();

            $table->spatialIndex('polygon', 'spx_service_area_polygons_polygon');
            $table->index('service_area_id', 'idx_service_area_polygons_area');

            $table->foreign('service_area_id', 'fk_service_area_polygons_area')
                ->references('id')->on('service_areas')
                ->onUpdate('cascade')
                ->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('service_area_polygons');
    }
};
