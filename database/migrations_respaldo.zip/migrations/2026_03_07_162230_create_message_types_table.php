<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('message_types', function (Blueprint $table) {
            $table->id();
            $table->string('code', 50)->unique(); // Ejemplo: text, template, system
            $table->string('name', 100); // Nombre del tipo de mensaje
            $table->boolean('is_active')->default(true); // Estado activo/inactivo
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('message_types');
    }
};
