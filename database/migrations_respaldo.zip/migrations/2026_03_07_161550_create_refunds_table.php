<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('refunds', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('payment_id');
            $table->unsignedInteger('status_id');
            $table->char('currency_code', 3)->default('MXN');
            $table->decimal('amount', 10, 2)->default(0.00);
            $table->string('reason', 255)->nullable();
            $table->string('gateway_reference', 150)->nullable();
            $table->json('raw_response')->nullable();
            $table->timestamps();

            $table->foreign('payment_id', 'fk_refunds_payment')
                ->references('id')->on('payments')
                ->onDelete('cascade')
                ->onUpdate('cascade');

            $table->foreign('status_id', 'fk_refunds_status')
                ->references('id')->on('status_types')
                ->onDelete('restrict')
                ->onUpdate('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('refunds');
    }
};
