<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('support_tickets', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('request_id');
            $table->unsignedBigInteger('opened_by');
            $table->unsignedBigInteger('assigned_to')->nullable();
            $table->unsignedInteger('status_id');
            $table->string('category', 80)->nullable();
            $table->string('priority', 20)->default('medium');
            $table->text('description');
            $table->text('resolution')->nullable();
            $table->timestamps();

            $table->foreign('request_id', 'fk_support_tickets_request')
                ->references('id')->on('assistance_requests')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('opened_by', 'fk_support_tickets_opened_by')
                ->references('id')->on('users')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('assigned_to', 'fk_support_tickets_assigned_to')
                ->references('id')->on('users')
                ->onDelete('set null')
                ->onUpdate('cascade');

            $table->foreign('status_id', 'fk_support_tickets_status')
                ->references('id')->on('status_types')
                ->onDelete('restrict')
                ->onUpdate('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('support_tickets');
    }
};
