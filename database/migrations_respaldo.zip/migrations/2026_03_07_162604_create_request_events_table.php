<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('request_events', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('request_id');
            $table->unsignedInteger('from_status_id')->nullable();
            $table->unsignedInteger('to_status_id')->nullable();
            $table->unsignedBigInteger('actor_user_id');
            $table->string('event_type', 80); // Ej: 'status_changed', 'provider_accepted', etc.
            $table->json('metadata')->nullable(); // Metadatos adicionales sobre el evento
            $table->timestamp('occurred_at');
            $table->timestamps();

            $table->foreign('request_id', 'fk_request_events_request')
                ->references('id')->on('assistance_requests')
                ->onDelete('cascade')
                ->onUpdate('cascade');

            $table->foreign('from_status_id', 'fk_request_events_from_status')
                ->references('id')->on('status_types')
                ->onDelete('set null')
                ->onUpdate('cascade');

            $table->foreign('to_status_id', 'fk_request_events_to_status')
                ->references('id')->on('status_types')
                ->onDelete('set null')
                ->onUpdate('cascade');

            $table->foreign('actor_user_id', 'fk_request_events_actor')
                ->references('id')->on('users')
                ->onDelete('restrict')
                ->onUpdate('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('request_events');
    }
};
