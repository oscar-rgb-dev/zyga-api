<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up(): void
{
    Schema::create('status_types', function (Blueprint $table) {
        $table->increments('id'); // INT UNSIGNED AUTO_INCREMENT
        $table->unsignedSmallInteger('domain_id'); // FK a status_domains.id (SMALLINT UNSIGNED)
        $table->string('code', 50);
        $table->string('name', 100);
        $table->string('description', 255)->nullable();
        $table->boolean('is_terminal')->default(false);
        $table->unsignedSmallInteger('sort_order')->default(0);
        $table->boolean('is_active')->default(true);
        $table->timestamps();

        $table->unique(['domain_id', 'code'], 'uq_status_types_domain_code');
        $table->foreign('domain_id', 'fk_status_types_domain')
            ->references('id')->on('status_domains')
            ->onUpdate('cascade')
            ->onDelete('restrict');
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('status_types');
    }
};
