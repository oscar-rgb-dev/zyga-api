<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('assistance_requests', function (Blueprint $table) {
            $table->id();
            $table->char('public_id', 26)->unique(); // Identificador público para la API
            $table->unsignedBigInteger('user_id'); // FK a users
            $table->unsignedBigInteger('provider_id')->nullable(); // FK a providers
            $table->unsignedSmallInteger('service_id'); // FK a services
            $table->unsignedBigInteger('vehicle_id')->nullable(); // FK a vehicles
            $table->unsignedBigInteger('service_area_id'); // FK a service_areas
            $table->geometry('pickup_location', 'point', 4326); // Ubicación geoespacial
            $table->string('pickup_reference', 255)->nullable();
            $table->unsignedInteger('current_status_id'); // FK a status_types
            $table->timestamps();

            $table->foreign('user_id', 'fk_assistance_requests_user')
                ->references('id')->on('users')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('provider_id', 'fk_assistance_requests_provider')
                ->references('id')->on('providers')
                ->onDelete('set null')
                ->onUpdate('cascade');

            $table->foreign('service_id', 'fk_assistance_requests_service')
                ->references('id')->on('services')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('vehicle_id', 'fk_assistance_requests_vehicle')
                ->references('id')->on('vehicles')
                ->onDelete('set null')
                ->onUpdate('cascade');

            $table->foreign('service_area_id', 'fk_assistance_requests_service_area')
                ->references('id')->on('service_areas')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('current_status_id', 'fk_assistance_requests_status')
                ->references('id')->on('status_types')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->spatialIndex('pickup_location', 'spx_assistance_requests_pickup');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('assistance_requests');
    }
};
