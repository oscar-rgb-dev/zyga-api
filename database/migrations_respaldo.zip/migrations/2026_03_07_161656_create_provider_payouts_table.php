<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('provider_payouts', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('provider_id');
            $table->unsignedBigInteger('request_id');
            $table->unsignedInteger('status_id');
            $table->char('currency_code', 3)->default('MXN');
            $table->decimal('amount', 10, 2)->default(0.00);
            $table->string('payout_reference', 150)->nullable();
            $table->timestamp('paid_at')->nullable();
            $table->timestamps();

            $table->foreign('provider_id', 'fk_provider_payouts_provider')
                ->references('id')->on('providers')
                ->onDelete('cascade')
                ->onUpdate('cascade');

            $table->foreign('request_id', 'fk_provider_payouts_request')
                ->references('id')->on('assistance_requests')
                ->onDelete('cascade')
                ->onUpdate('cascade');

            $table->foreign('status_id', 'fk_provider_payouts_status')
                ->references('id')->on('status_types')
                ->onDelete('restrict')
                ->onUpdate('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('provider_payouts');
    }
};
