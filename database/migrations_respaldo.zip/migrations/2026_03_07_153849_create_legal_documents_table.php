<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up(): void
{
    Schema::create('legal_documents', function (Blueprint $table) {
        $table->id(); // BIGINT UNSIGNED
        $table->unsignedSmallInteger('consent_type_id'); // FK a consent_types.id
        $table->string('version', 30); // ej: "1.0", "2026-03"
        $table->string('title', 200);
        $table->text('body_text'); // contenido legal (o almacenar URL si prefieres)
        $table->date('effective_from')->nullable();
        $table->boolean('is_active')->default(true);
        $table->timestamps();

        $table->unique(['consent_type_id', 'version'], 'uq_legal_documents_type_version');
        $table->foreign('consent_type_id', 'fk_legal_documents_consent_type')
            ->references('id')->on('consent_types')
            ->onUpdate('cascade')
            ->onDelete('restrict');
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('legal_documents');
    }
};
