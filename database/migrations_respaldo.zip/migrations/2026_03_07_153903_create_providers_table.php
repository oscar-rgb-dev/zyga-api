<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('providers', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->unique(); // Relación 1:1 con users
            $table->string('display_name', 150);
            $table->string('provider_kind', 50)->nullable(); // Ej: tow_truck, mechanic, etc.
            $table->unsignedInteger('status_id'); // FK a status_types.id
            $table->boolean('is_verified')->default(false);
            $table->timestamps();

            $table->index('status_id', 'idx_providers_status');

            // Claves foráneas con eliminación en cascada
            $table->foreign('user_id', 'fk_providers_user')
                ->references('id')->on('users')
                ->onUpdate('cascade')
                ->onDelete('cascade'); // Cascada al eliminar el usuario relacionado

            $table->foreign('status_id', 'fk_providers_status')
                ->references('id')->on('status_types')
                ->onUpdate('cascade')
                ->onDelete('cascade'); // Cascada al eliminar el estado
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('providers');
    }
};
