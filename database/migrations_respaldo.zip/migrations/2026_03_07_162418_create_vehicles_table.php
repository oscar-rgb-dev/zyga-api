<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('vehicles', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->unsignedSmallInteger('vehicle_type_id');
            $table->string('make', 100)->nullable(); // Marca del vehículo
            $table->string('model', 100)->nullable(); // Modelo del vehículo
            $table->string('color', 50)->nullable(); // Color del vehículo
            $table->string('plate', 20)->nullable(); // Placa del vehículo
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->foreign('user_id', 'fk_vehicles_user')
                ->references('id')->on('users')
                ->onDelete('cascade')
                ->onUpdate('cascade');

            $table->foreign('vehicle_type_id', 'fk_vehicles_type')
                ->references('id')->on('vehicle_types')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->index('plate', 'idx_vehicles_plate');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('vehicles');
    }
};
