<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('device_tokens', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->unsignedSmallInteger('platform_id');
            $table->binary('token_hash');
            $table->string('token_last4', 8)->nullable();
            $table->timestamp('created_at')->nullable();
            $table->timestamp('last_seen_at')->nullable();
            $table->timestamp('revoked_at')->nullable();
            $table->timestamps();

            $table->foreign('user_id', 'fk_device_tokens_user')
                ->references('id')->on('users')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('platform_id', 'fk_device_tokens_platform')
                ->references('id')->on('device_platform_types')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->unique('token_hash', 'uq_device_tokens_hash');
            $table->index('user_id', 'idx_device_tokens_user');
            $table->index('platform_id', 'idx_device_tokens_platform');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('device_tokens');
    }
};
