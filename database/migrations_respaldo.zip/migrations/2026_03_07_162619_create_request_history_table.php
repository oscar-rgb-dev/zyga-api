<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('request_history', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('request_id');
            $table->unsignedInteger('version_no');
            $table->json('snapshot'); // Representación completa del estado de la solicitud
            $table->unsignedBigInteger('changed_by');
            $table->timestamp('changed_at');
            $table->string('reason', 255)->nullable();
            $table->timestamps();

            $table->foreign('request_id', 'fk_request_history_request')
                ->references('id')->on('assistance_requests')
                ->onDelete('cascade')
                ->onUpdate('cascade');

            $table->foreign('changed_by', 'fk_request_history_changed_by')
                ->references('id')->on('users')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->unique(['request_id', 'version_no'], 'uq_request_history_version');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('request_history');
    }
};
