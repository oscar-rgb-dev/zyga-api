<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('assistance_requests', function (Blueprint $table) {
            $table->id();
            $table->char('public_id', 26)->unique();
            $table->unsignedBigInteger('user_id'); // FK a users
            $table->unsignedBigInteger('provider_id')->nullable(); // FK a providers
            $table->unsignedSmallInteger('service_id'); // FK a services, corrijo el tipo
            $table->unsignedBigInteger('vehicle_id')->nullable(); // FK a vehicles
            $table->unsignedBigInteger('service_area_id')->nullable(); // FK a service_areas
            $table->geometry('pickup_location', 'point', 4326); // Ubicación
            $table->unsignedInteger('current_status_id'); // FK a status_types
            $table->timestamps();

            $table->foreign('user_id')->references('id')->on('users')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('provider_id')->references('id')->on('providers')->onUpdate('cascade')->onDelete('set null');
            $table->foreign('service_id')->references('id')->on('services')->onUpdate('cascade')->onDelete('restrict');
            $table->foreign('vehicle_id')->references('id')->on('vehicles')->onUpdate('cascade')->onDelete('set null');
            $table->foreign('service_area_id')->references('id')->on('service_areas')->onUpdate('cascade')->onDelete('set null');
            $table->foreign('current_status_id')->references('id')->on('status_types')->onUpdate('cascade')->onDelete('restrict');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('assistance_requests');
    }
};
