<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up(): void
{
    Schema::create('consent_types', function (Blueprint $table) {
        $table->smallIncrements('id'); // SMALLINT UNSIGNED
        $table->string('code', 50)->unique(); // ej: terms, privacy, marketing
        $table->string('name', 100);
        $table->string('description', 255)->nullable();
        $table->boolean('is_active')->default(true);
        $table->timestamps();
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('consent_types');
    }
};
