<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('messages', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('request_id');
            $table->unsignedBigInteger('sender_user_id');
            $table->unsignedSmallInteger('message_type_id');
            $table->text('body_text')->nullable();
            $table->unsignedBigInteger('template_id')->nullable();
            $table->timestamps();

            $table->foreign('request_id', 'fk_messages_request')
                ->references('id')->on('assistance_requests')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('sender_user_id', 'fk_messages_sender')
                ->references('id')->on('users')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('message_type_id', 'fk_messages_type')
                ->references('id')->on('message_types')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('template_id', 'fk_messages_template')
                ->references('id')->on('message_templates')
                ->onDelete('set null')
                ->onUpdate('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('messages');
    }
};
