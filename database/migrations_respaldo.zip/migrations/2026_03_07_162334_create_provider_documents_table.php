<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('provider_documents', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('provider_id');
            $table->unsignedSmallInteger('document_type_id');
            $table->unsignedInteger('status_id');
            $table->text('file_url');
            $table->char('file_hash', 64)->nullable();
            $table->date('expires_at')->nullable();
            $table->unsignedBigInteger('reviewed_by')->nullable();
            $table->timestamp('reviewed_at')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->foreign('provider_id', 'fk_provider_documents_provider')
                ->references('id')->on('providers')
                ->onDelete('cascade')
                ->onUpdate('cascade');

            $table->foreign('document_type_id', 'fk_provider_documents_doc_type')
                ->references('id')->on('provider_document_types')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('status_id', 'fk_provider_documents_status')
                ->references('id')->on('status_types')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('reviewed_by', 'fk_provider_documents_reviewed_by')
                ->references('id')->on('users')
                ->onDelete('set null')
                ->onUpdate('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('provider_documents');
    }
};
