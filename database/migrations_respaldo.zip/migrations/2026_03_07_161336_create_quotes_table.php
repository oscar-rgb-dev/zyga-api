<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('quotes', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('request_id');
            $table->unsignedBigInteger('pricing_rule_id')->nullable();
            $table->char('currency_code', 3)->default('MXN');
            $table->decimal('subtotal', 10, 2)->default(0.00);
            $table->decimal('platform_fee', 10, 2)->default(0.00);
            $table->decimal('total', 10, 2)->default(0.00);
            $table->dateTime('calculated_at');
            $table->timestamps();

            $table->foreign('request_id', 'fk_quotes_request')
                ->references('id')->on('assistance_requests')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('pricing_rule_id', 'fk_quotes_pricing_rule')
                ->references('id')->on('pricing_rules')
                ->onDelete('set null')
                ->onUpdate('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('quotes');
    }
};
