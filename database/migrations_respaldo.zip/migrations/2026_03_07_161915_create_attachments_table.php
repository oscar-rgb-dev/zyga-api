<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('attachments', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('request_id');
            $table->unsignedBigInteger('uploaded_by');
            $table->unsignedSmallInteger('attachment_type_id');
            $table->text('file_url');
            $table->char('file_hash', 64)->nullable();
            $table->timestamps();

            $table->foreign('request_id', 'fk_attachments_request')
                ->references('id')->on('assistance_requests')
                ->onDelete('cascade')
                ->onUpdate('cascade');

            $table->foreign('uploaded_by', 'fk_attachments_uploaded_by')
                ->references('id')->on('users')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('attachment_type_id', 'fk_attachments_type')
                ->references('id')->on('attachment_types')
                ->onDelete('restrict')
                ->onUpdate('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('attachments');
    }
};
