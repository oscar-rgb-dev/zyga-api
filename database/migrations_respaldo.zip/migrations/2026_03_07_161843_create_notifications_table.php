<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('notifications', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->unsignedSmallInteger('notification_type_id');
            $table->unsignedInteger('status_id');
            $table->string('title', 150)->nullable();
            $table->text('body')->nullable();
            $table->json('payload')->nullable();
            $table->unsignedInteger('attempts')->default(0);
            $table->timestamp('next_attempt_at')->nullable();
            $table->timestamp('sent_at')->nullable();
            $table->string('failure_reason', 255)->nullable();
            $table->timestamps();

            $table->foreign('user_id', 'fk_notifications_user')
                ->references('id')->on('users')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('notification_type_id', 'fk_notifications_type')
                ->references('id')->on('notification_types')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('status_id', 'fk_notifications_status')
                ->references('id')->on('status_types')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->index('user_id', 'idx_notifications_user_time');
            $table->index('status_id', 'idx_notifications_dispatch');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('notifications');
    }
};
