<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('request_id');
            $table->unsignedInteger('status_id');
            $table->unsignedSmallInteger('payment_method_id');
            $table->unsignedSmallInteger('gateway_id')->nullable();
            $table->char('currency_code', 3)->default('MXN');
            $table->decimal('amount', 10, 2)->default(0.00);
            $table->char('idempotency_key', 36)->unique();
            $table->string('gateway_reference', 150)->nullable();
            $table->timestamp('authorized_at')->nullable();
            $table->timestamp('captured_at')->nullable();
            $table->timestamp('paid_at')->nullable();
            $table->string('failure_reason', 255)->nullable();
            $table->timestamps();

            $table->foreign('request_id', 'fk_payments_request')
                ->references('id')->on('assistance_requests')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('status_id', 'fk_payments_status')
                ->references('id')->on('status_types')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('payment_method_id', 'fk_payments_method')
                ->references('id')->on('payment_method_types')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('gateway_id', 'fk_payments_gateway')
                ->references('id')->on('payment_gateway_types')
                ->onDelete('set null')
                ->onUpdate('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payments');
    }
};
