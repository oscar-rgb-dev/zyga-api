<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payment_transactions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('payment_id');
            $table->unsignedInteger('status_id');
            $table->string('transaction_type', 50); // Ej: 'authorization', 'capture', 'refund'
            $table->string('gateway_event_id', 150)->nullable();
            $table->string('gateway_reference', 150)->nullable();
            $table->json('raw_response')->nullable(); // Respuesta cruda del gateway
            $table->timestamp('processed_at');
            $table->timestamps();

            $table->foreign('payment_id', 'fk_payment_tx_payment')
                ->references('id')->on('payments')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('status_id', 'fk_payment_tx_status')
                ->references('id')->on('status_types')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->unique('gateway_event_id', 'uq_payment_tx_gateway_event'); // Evitar duplicados en eventos del gateway
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payment_transactions');
    }
};
