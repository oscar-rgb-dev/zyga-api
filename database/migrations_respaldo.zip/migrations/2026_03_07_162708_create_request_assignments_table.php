<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('request_assignments', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('request_id');
            $table->unsignedBigInteger('provider_id');
            $table->unsignedBigInteger('assigned_by')->nullable();
            $table->timestamp('assigned_at');
            $table->timestamp('unassigned_at')->nullable();
            $table->string('unassign_reason', 255)->nullable();
            $table->string('assignment_source', 50)->default('auto'); // auto/admin/provider
            $table->timestamps();

            $table->foreign('request_id', 'fk_request_assignments_request')
                ->references('id')->on('assistance_requests')
                ->onDelete('cascade')
                ->onUpdate('cascade');

            $table->foreign('provider_id', 'fk_request_assignments_provider')
                ->references('id')->on('providers')
                ->onDelete('restrict')
                ->onUpdate('cascade');

            $table->foreign('assigned_by', 'fk_request_assignments_assigned_by')
                ->references('id')->on('users')
                ->onDelete('set null')
                ->onUpdate('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('request_assignments');
    }
};
